// 01 · Oscilador + ganancia. Punto de partida de la Actividad 1.
let ctx: AudioContext | null = null;
let osc: OscillatorNode | null = null;
let gain: GainNode | null = null;

const $ = (id: string) => document.getElementById(id)!;
const play = $('play') as HTMLButtonElement;
const stop = $('stop') as HTMLButtonElement;
const state = $('state');

play.addEventListener('click', async () => {
  if (!ctx) ctx = new AudioContext();           // creado dentro del gesto de usuario
  await ctx.resume();
  state.textContent = ctx.state;

  if (!gain) { gain = ctx.createGain(); gain.gain.value = 0.2; gain.connect(ctx.destination); }

  osc = ctx.createOscillator();                 // TODO 3: ¿por qué hay que crear uno nuevo cada vez?
  osc.type = 'sine';
  osc.frequency.value = 440;
  osc.connect(gain);
  osc.start();

  play.disabled = true; stop.disabled = false;
});

stop.addEventListener('click', () => {
  // TODO 3: parar el oscilador y dejar "Tocar" operativo.
  //   osc?.stop(); osc = null;
  play.disabled = false; stop.disabled = true;
});

// TODO 1: slider de frecuencia → osc.frequency (pista: es un AudioParam; hoy vale .value, en T2 setTargetAtTime).
// TODO 2: selector de tipo de onda → osc.type.
// TODO 4 (extra): segundo oscilador con detune = +8 (cents) mezclado en el mismo gain.
